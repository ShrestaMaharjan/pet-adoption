import React, { useState } from "react";
import "./AuthForms.css"; // You'll need to create this CSS file

// SignUp Component
export const SignUp = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle signup logic here
    console.log(formData);
  };

  return (
    <div className="auth-container">
      <h1>Create an Account</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="firstName">First Name</label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="lastName">Last Name</label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="email">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="phone">Phone Number</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="confirmPassword">Confirm Password</label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            required
          />
        </div>

        <div className="divider">---</div>

        <button type="submit" className="primary-btn">
          Create Account
        </button>

        <div className="divider">OR</div>

        <button type="button" className="google-btn">
          Sign in with Google
        </button>

        <p className="auth-switch">
          Already have an account? <a href="/login">Log in</a>
        </p>
      </form>
    </div>
  );
};

// Login Component
export const Login = () => {
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
    rememberMe: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setLoginData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle login logic here
    console.log(loginData);
  };

  return (
    <div className="auth-page">
      <nav className="auth-nav">
        <a href="/about">About Us</a>
        <a href="/adoption">Pet Adoption</a>
        <a href="/stories">Pet Stories</a>
        <a href="/rehome">Rehome Pet</a>
        <a href="/volunteer">Volunteer</a>
        <a href="/login">Login</a>
      </nav>

      <div className="auth-container">
        <h1>Log in to Your Account</h1>
        <p className="auth-description">
          For a very willing sign you will login and you will discover your name
          and speak.
        </p>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="loginEmail">Enter Email Address</label>
            <input
              type="email"
              id="loginEmail"
              name="email"
              value={loginData.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="loginPassword">Password</label>
            <input
              type="password"
              id="loginPassword"
              name="password"
              value={loginData.password}
              onChange={handleChange}
              required
            />
          </div>

          <div className="remember-me">
            <input
              type="checkbox"
              id="rememberMe"
              name="rememberMe"
              checked={loginData.rememberMe}
              onChange={handleChange}
            />
            <label htmlFor="rememberMe">Remember me?</label>
          </div>

          <button type="submit" className="primary-btn">
            Log in
          </button>

          <div className="divider">OR</div>

          <button type="button" className="google-btn">
            Sign in with Google
          </button>

          <p className="auth-switch">
            Don't have an account yet? <a href="/signup">Sign up</a>
          </p>
        </form>
      </div>
    </div>
  );
};
